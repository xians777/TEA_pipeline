/*
 * MathUtil.cpp
 *
 *  Created on: Aug 17, 2016
 *      Author: el174
 */

#include "MathUtils.hpp"

namespace castle {

MathUtils::MathUtils() {
}

MathUtils::~MathUtils() {
}

} /* namespace tea */
